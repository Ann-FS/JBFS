console.log('connected');
function runScript(){

    document.getElementsByTagName('h1')[0].innerHTML = "New world";

}