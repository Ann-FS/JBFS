const miningfullNames = 12;

const userInput1 = prompt("Insert number 1");

const userInputList = prompt("Please insert list of numbers, (comma separated)");
// userInputList.split(",")

// const space between words = "Text";

// const 1stCharIsNumber = "Example"; 

// const user-input-list = "Special Char";

const user_input_list = "You can do that";

const camleCase = "Start with lower case and start with capital letter new words"; 

const text = 'Example';
const text2 = "Example double";
const text3 = `Example`;
const apostrophe = 'This isn\'t';



