const yourName = prompt("What is your name ?");
const yourAge = prompt("What is your age ?");
alert("Welcome " + yourName + ", " + yourAge + " is a great age!");