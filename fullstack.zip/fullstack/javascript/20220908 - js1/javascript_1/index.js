const basicMessage = "My name is "
let name = "Yos";
let message = basicMessage; 

console.log(message)

message = basicMessage + name;
console.log(message);

name = "Moshe";
console.log(message);

message = basicMessage + name;
console.log(message);