const text= "Test text";

console.log(typeof text);

console.log(typeof 8);

console.log(typeof true);

console.log(typeof false);

