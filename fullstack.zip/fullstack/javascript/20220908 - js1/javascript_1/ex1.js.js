// get user input using prompt for each number
const num1 = prompt("Insert number 1");
console.log("got num " + num1);
const num2 = prompt("Insert number 2");
console.log("got num " + num2);
const num3 = prompt("Insert number 3");
console.log("got num " + num3);

console.log(num1 + num2 + num3);

// convert to number
const converted1 = Number(num1);
console.log("converted num " + converted1);
const converted2 = parseInt(num2);
console.log("converted num " + converted2);
const converted3 = Number(num3);
console.log("converted num " + converted3);

// calc the sum and assign it
const sum = converted1 + converted2 + converted3;
// calc the avg and assign it
const avg = sum / 3; 
// log the results
console.log("The sum is: " + sum);
console.log("The avg is: ".concat(avg));
// alert the results with meassage
alert("The sum is: " + sum + "\n" + "The avg is: " + avg);

// when we concat string and number number will be treated as string.

// console.log("Sum is " + converted1 + converted2 + converted3)
// console.log("Sum is " + (converted1 + converted2 + converted3))
