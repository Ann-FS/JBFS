let index = 0;
while(index < 100) {
    index++
}

for (let index = 0; index < bound; index++) {
    
};