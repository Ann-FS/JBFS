# js_part_4_homework

A Pen created on CodePen.io. Original URL: [https://codepen.io/yos-israel/pen/rNvmpmV](https://codepen.io/yos-israel/pen/rNvmpmV).

