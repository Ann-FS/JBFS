console.log('From index.js');


// const Car = {
//     door: 4,
//     model: "Ford",
//     color: "red",

//     break: function(){
//         console.log('breaked');
//     }
// }