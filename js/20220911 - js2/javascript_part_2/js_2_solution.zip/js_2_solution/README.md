# JS_2_solution

A Pen created on CodePen.io. Original URL: [https://codepen.io/yos-israel/pen/YzLGoLL](https://codepen.io/yos-israel/pen/YzLGoLL).

