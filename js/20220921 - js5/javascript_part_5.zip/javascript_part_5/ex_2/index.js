const btn = document.querySelector('button');
btn.addEventListener('click', handleClick);

function handleClick(){
    alert('Clicked');
}


const headers = document.getElementsByTagName('h1');
const headers2 = document.querySelectorAll('h1');