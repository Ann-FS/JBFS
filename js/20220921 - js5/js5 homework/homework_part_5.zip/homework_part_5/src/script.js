// question 1 
const myNameButton = document.querySelector('#myName');
myNameButton.addEventListener('click', handleMyNameClick)

function handleMyNameClick (){
   alert("Yos Israel");
}

// question 2
const colorChangerBtn = document.querySelector('#colorChanger');

colorChangerBtn.addEventListener('click', handleColorChange);

function handleColorChange (){
  document.querySelector('body').style.backgroundColor = "pink"
}

// question 3
const headerSetterInput = document.querySelector('#headerSetter');
const header1 =  document.querySelector('#inputHeader');

headerSetterInput.addEventListener('keyup', handleChnageHeader);

function handleChnageHeader(event) {
  header1.innerHTML =  headerSetterInput.value;
}

// question 3

const body = document.querySelector('body');

function handleChange(event) {
   const selected = event.target.value;
  
  if(selected == 1) {
    body.style.backgroundColor = 'red';
  }else if(selected == 2){
    body.style.backgroundColor = 'yellow';  
  }else {
    body.style.backgroundColor = 'green';  
  }
  
}
// Question 4

const colorCharInput = document.querySelector('#colorChar');
colorCharInput.addEventListener('keydown', handleColorChar);
colorCharInput.classList.add('blue');

function handleColorChar(event) {
  colorCharInput.classList.toggle('red');
  colorCharInput.classList.toggle('blue');
}

// Question 5 
colorCharInput.addEventListener('blur', handleBlur);
function handleBlur (event){
   alert(event.target.value);
}

// Question 6 
imageHover.addEventListener('mouseover', handleHover);
imageHover.addEventListener('click', handleBeforLeft)


let imageHoverCounter = 0;
function handleHover(event) {
 imageHoverCounter++; 
}

function handleBeforLeft(event) {
  alert(`User hovered image ${imageHoverCounter} times`);
}

// question 7
const form = document.querySelector('#userInfo');
const inputs = document.querySelectorAll('form input');
form.addEventListener('submit', handleSubmit);
inputs.forEach(item => {
  addEventListener('keydown', resetHelpText);
})


function handleSubmit(event){
  event.preventDefault();
  let item = {};
  const formData = new FormData(form);
  formData.forEach((value, key) => {
    item[key] = value;
  })
  validateForm(item);
}



function validateForm(item) {
  console.log(item);
  const  requierdMessage =  "This field is required";
  if(!item.name || item.name.length < 1) {
    document.querySelector('#nameHelp').innerHTML = requierdMessage;
  } else if(isNaN(item.age)){
        document.querySelector('#ageHelp').innerHTML = requierdMessage;
  } else if(!isEmailValid){
      document.querySelector('#emailHelp').innerHTML = requierdMessage;  
  }else {
     console.log(item); 
  }
}

function resetHelpText(){
  document.querySelector('#nameHelp').innerHTML = "";
  document.querySelector('#ageHelp').innerHTML = "";
  document.querySelector('#emailHelp').innerHTML = "";
}



function isEmailValid (email) {
  return item.email && item.email.length > 1 && item.email.indexOf('@') > -1;
}